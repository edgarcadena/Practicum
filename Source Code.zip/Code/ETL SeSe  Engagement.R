#Auxiliary script to pull sample SeSe sessioons
library(RODBC)

#Query to pull sample sessions
query <- 
"
  SELECT 
  D.CAL_DT AS SESSION_DT,
  SITES.SITE_NAME AS SITE,
  S.SESSION_ID,
  S.SESSION_BEGIN_DATE,
  S.SESSION_END_DATE,
  S.MOBILE_FLAG,
  ENG.RESOLVED_FLG AS RESOLVED_FLAG,
  CSEG.CUST_SEGMENT_NAME AS CUSTOMER_SEGMENT,
  ROUND((CAST (S.SESSION_BEGIN_DATE AS DATE) - DNA.USR_CREATED_DT) / 30) CUSTOMER_TENURE,
  S.SEGMENT_CNT,
  SG.SUA_COMPONENT_ID AS COMPONENT_ID, 
  SG.SUA_PAGE_ID AS TOPIC_ID,
  SHP.SUA_L1_TOPIC_DESC AS L1_TOPIC,
  SHP.SUA_L2_TOPIC_DESC AS L2_TOPIC,
  A.ACTION_DATE,
  A.SEGMENT_SEQUENCE_NUMBER,
  A.ATTRIBUTE_ID,
  ATT.ATTRIBUTE_NAME,		
  A.ATTRIBUTE_VALUE
FROM
  MIDW_ACCESS_VIEWS.P_F_SUA_SESSION S
  JOIN MIDW_ACCESS_VIEWS.P_F_SUA_ACTION A ON (S.SESSION_ID = A.SESSION_ID AND S.SUA_APP_INSTANCE_ID = A.SUA_APP_INSTANCE_ID  AND 
  S.SESSION_BEGIN_CAL_ID = A.SESSION_BEGIN_CAL_ID)
  JOIN MIDW_ACCESS_VIEWS.P_F_SUA_SEGMENT SG ON (A.SESSION_ID = SG.SESSION_ID AND A.SESSION_BEGIN_CAL_ID = SG.SESSION_BEGIN_CAL_ID AND 
  A.SEGMENT_SEQUENCE_NUMBER = SG.SEGMENT_SEQUENCE_NUMBER AND A.SUA_APP_INSTANCE_ID = SG.SUA_APP_INSTANCE_ID)
  JOIN EBAY_CS_T.CS_ATTRIBUTE ATT ON A.ATTRIBUTE_ID = ATT.ATTRIBUTE_ID
  JOIN ACCESS_VIEWS.DW_SITES SITES ON (S.SITE_ID = SITES.SITE_ID)
  JOIN D_CAL_CALENDAR DWCALID ON (S.SESSION_BEGIN_CAL_ID = DWCALID.CAL_ID)
  JOIN ACCESS_VIEWS.DW_CAL_DT D ON (D.CAL_DT = DWCALID .PACIFIC_CALENDAR_DATE)
  JOIN P_IA_SESE_T.P_SESE_ENG eng on eng.session_id = s.session_id
  LEFT JOIN PRS_CSDW_L2_PII_V.D_OCS_CUST_SEGMENT CSEG ON CSEG.OCS_CUST_SEG_ID = S.SUA_SEGMENT_ID
  LEFT JOIN PRS_SECURE_V.USER_DNA DNA ON DNA.USER_ID = S.USER_ID
  LEFT JOIN MIDW_ACCESS_VIEWS.D_SUA_HELP_PAGE SHP ON (CASE WHEN SG.SUA_APP_INSTANCE_ID = 44 THEN SG.SITE_ID ELSE 0 END = SHP.SITE_ID AND 
  SG.SUA_PAGE_ID = SHP.SUA_PAGE_ID AND SG.SUA_APP_INSTANCE_ID = SHP.SUA_APP_INSTANCE_ID)
WHERE
  SESSION_DT  BETWEEN '2016-06-01' AND '2016-07-31'
  AND S.SESSION_ID NOT IN (SELECT SESSION_ID FROM P_GSS_BL_T.INFLOWEUA)
  AND S.ACTIVE_FLAG=1
  AND  S.OCS_FLAG = 1
  AND S.SITE_ID IN (0,3,15,77)
  AND SG.SUA_COMPONENT_ID IN (6,5,1,9,10) -- SELF-SERVICE, OCS CONTACT US, HELP, OCS COMMUNITY HELP SERVICE, OCS PREDICTION SERVICE
  AND A. ATTRIBUTE_ID IN 
  (
    
    '500000441222',	--POPULARSOLUTIONCLICKED
    '5000002470',		--TOPICID
    '5000002910',		--OCSUSERSELFSERVICECONTEXT
    '5000003140',		--OCSUSERENTEREDQUERY
    '5000002960',		--OCSAUTOSUGGESTUSED
    '5000002430',		--QUERY
    '50000043025',		--OCSCOMMUNITYUSERSELFSERVICECONTEXT
    '50000043024',		--OCSCOMMUNITYTHREADCLICKED
    '5000002860',		--OCSCLICKEDGSARESULTSLINK
    '50000043045', 	--SUPERDTTOPICCLICKED
    '50000043029',		--TOPIC_BROWSED
    '50000043042',		--OCSPREDICTIONSCLICKED
    '5000001510'			--CHANNEL_CLICKED
    
  )
  /*AND
  (
    S.SESSION_ID IN ('68883446822','68883447191','68883461365','68883473360','68883488884')--COMMUNITY SAMPLE SESSIONS
    OR S.SESSION_ID IN ('5423376207','5423376210','5423376225','5423376236','5423376247','68890010544','68890006560','68889986834','68889980852','68889979839')--RELATED HELP
    OR S.SESSION_ID IN ('5423377310','5423377321','68880768389','68880770953','68880772789')-- POPULAR SOLUTIONS
    OR S.SESSION_ID IN ('68887392482','68887392181','68887388642','68887386388','68887384582') -- SIP
    OR S.SESSION_ID IN ('5423377333','68880770674','68880770866','68880774037','68880775176')  --TOPIC BROWSED
    OR S.SESSION_ID IN ('5423377310','5423377321','68880774037','68880792382','68880793459') --PREDICTIONS
    OR S.SESSION_ID IN ('68881081530','68881081773','68881084583','68881086082','68881087358')--SEARCH
  )*/
  AND S.SESSION_ID IN (SELECT DISTINCT SESSION_ID FROM P_IA_SESE_T.P_SESE_ENG)
"
  
#Pulls invalid search phrases
querySearchExcl <- "SELECT DISTINCT ATTRIBUTE_VALUE FROM  P_CSTECH_SESE_T. SEARCHEXCL"

#Pull all SeSe sample sessions
dsn <- "mozart64"
con <- odbcConnect(dsn)
searchExcl <- sqlQuery(con,querySearchExcl,max=0)
print(system.time(sese001 <- sqlQuery(con,query,max=1000)))

for (i in 1:1000){
  print(paste(i,system.time(result <- sqlGetResults(con,max=1000))))
  if (result == -1) {
    break
  }
  sese001 <- rbind(sese001,result)
}
close(con)  

#Order dataframe for processing (session_id, seq_number, action_date)
#sese001 <- sese001[order(sese001[,"session_id"],sese001[,"segment_sequence_number"],sese001[,"action_date"]),]
sese001 <- sese001[order(sese001[,"session_id"],sese001[,"action_date"]),]

#Get unique set of sessions to be processed
uniqueSes <- unique(sese001$session_id)

#Convert machine search phrases to string
searchTxt <- as.character(searchExcl[,1])

#Traverse list of sessions to create sequence-based and interest-based representations
for (i in seq(uniqueSes)) {
#for (i in 1:10) {
  session <- sese001[sese001$session_id==uniqueSes[i],]
  
  #Collect session's main attributes
  session_dt           <- session[1,"SESSION_DT"]
  site                 <- session[1,"SITE"]
  session_id           <- session[1,"session_id"]
  mobile_flag          <- session[1,"mobile_flag"]
  customer_segment     <- session[1,"CUSTOMER_SEGMENT"]
  customer_presence    <- session[1,"CUSTOMER_TENURE"]
  startTime            <- session[1,"session_begin_date"] 
  resolved_flag        <- session[1,"RESOLVED_FLAG"] 
  
  #Initialize segment arrays
  seseSegments <- rep("",50)
  seseSegIndex <- 0
  seseCounts <- rep(0,8)
  seseDurns <- rep(0,8)
  seseComponents <- rep("",8)
  seseCompAbrv <- rep("",8)
  seseAvgDurn <- rep(0,8)
  seseComponents[1] <- "Topic Browsed"      #T
  seseComponents[2] <- "Popular Solution"   #P
  seseComponents[3] <- "Search"             #S
  seseComponents[4] <- "Community"          #C
  seseComponents[5] <- "Related Help"       #H
  seseComponents[6] <- "Super Item Picker"  #I
  seseComponents[7] <- "Prediction"         #R
  seseComponents[8] <- "Escalation"         #E
  seseCompAbrv[1] <- "T"      
  seseCompAbrv[2] <- "P"   
  seseCompAbrv[3] <- "S"             
  seseCompAbrv[4] <- "C"          
  seseCompAbrv[5] <- "H"       
  seseCompAbrv[6] <- "I"  
  seseCompAbrv[7] <- "R"         
  seseCompAbrv[8] <- "E"         
  seseAvgDurn[1] <- 17
  seseAvgDurn[2] <- 42
  seseAvgDurn[3] <- 24
  seseAvgDurn[4] <- 8
  seseAvgDurn[5] <- 13
  seseAvgDurn[6] <- 18
  seseAvgDurn[7] <- 13
  seseAvgDurn[8] <- 100
  
  lastcomp <- "(SeSe)"
  lastsese <- 0
  sese <- 0
  seqString <- ""
  
  rows <- nrow(session)
  for (j in 1:rows) {
    att_id <- session[j,"attribute_id"]
    att_val <- as.character(session[j,"attribute_value"])
    sua_component_id     <- session[j,"COMPONENT_ID"]
    
    #Label OCS component
    if (sua_component_id == 6){
      component <- "(SeSe)"
    } else { 
      if (sua_component_id == 5) {
        component <- "(CU)"
      } else { 
        if (sua_component_id == 1) {
          component <- "(Help)"
        } else { 
          if (sua_component_id == 9) {
            component <- "(Community)"
          } else { 
            if (sua_component_id == 10) {
              component <- "(Prediction)"
            }  else {
              component <- "(Unknown)"
            }
          }
        }
      }
    }
    
    #Label SeSe component
    if (att_id == 50000043029){
      sese <- 1 #Topic Browsed
    } else { 
      if (att_id == 500000441222) {
        sese <- 2 #Popular Solution
        if (lastsese == 7 && startTime == session[j,"action_date"]){
          sese <- 0
        }
      } else { 
        if (att_id == 5000003140 && ifelse(is.na(att_val),-1,sum(att_val == searchTxt)) == 0) {
          sese <- 3 #Search
        } else { 
          if (att_id == 50000043024) {
            sese <- 4 #Community
            component <- lastcomp
          } else { 
            if (att_id == 5000002860 && j != 1) {
              sese <- 5 #Related Help
              component <- lastcomp
            } else { 
              if (att_id == 50000043045) {
                sese <- 6 #Super Item Picker
              } else { 
                if (att_id == 50000043042) {
                  sese <- 7 #Prediction
                  component <- lastcomp
                  if (lastsese == 2 && startTime == session[j,"action_date"]){
                    seseSegIndex <- seseSegIndex - 1
                    seseCounts[2] <- seseCounts[2] - 1 
                    lastsese <- 0
                  }
                } else { 
                  if (att_id == 5000001510) {
                    sese <- 8 #Escalation
                    component <- "(CU)"
                  }else { 
                    if (att_id == 5000002910) {
                      if (att_val == "CuSelfService") {
                        lastcomp <- "(CU)"
                      } else {
                        if (att_val == "OcsSelfService"){
                          lastcomp <- "(SeSe)"
                        }
                      }
                    }
                    sese <- 0
                  }
                }
              }
            }
          }
        }
      }
    }
    
    if (sese > 0){
      seseStr <- paste(component,seseComponents[sese],sep="-")
      seseSegIndex <- seseSegIndex + 1
      seseSegments[seseSegIndex] <- seseStr
      seqString <- paste(seqString,seseCompAbrv[sese],sep="")
      seseCounts[sese] <- seseCounts[sese] + 1
      if (lastsese > 0){
        seseDurns[lastsese] <- seseDurns[lastsese] + as.numeric(difftime(session[j,"action_date"],startTime, units = "secs"))
      } 
      lastsese <- sese
      startTime <- session[j,"action_date"]
    }
  }
  
  print(paste(i,session_id))
  
  if (lastsese > 0){
    cntDurns <- sum(seseDurns != 0)
    if (cntDurns > 0) {
      seseDurns[lastsese] <- seseDurns[lastsese] + round(sum(seseDurns) / cntDurns)
    }
  } 
  
  seseFrequency <- seseCounts / sum(seseCounts)
  seseDuration  <- (seseDurns / seseAvgDurn) / max(seseDurns / seseAvgDurn)
  seseInterest <- (2 * seseFrequency * seseDuration) / (seseFrequency + seseDuration)
  seseInterest <- sapply(seseInterest, FUN =function(x) ifelse(is.nan(x),0,x))

  
  seseSession <- data.frame(session_dt,
                                site,
                                session_id,
                                mobile_flag,
                                customer_segment, 
                                customer_presence,
                                resolved_flag,
                                seseSegIndex,
                                seqString,
                                seseSegments[1], seseSegments[2], seseSegments[3],seseSegments[4],seseSegments[5],
                                seseSegments[6], seseSegments[7], seseSegments[8],seseSegments[9],seseSegments[10],
                                seseSegments[11], seseSegments[12], seseSegments[13],seseSegments[14],seseSegments[15],
                                seseSegments[16], seseSegments[17], seseSegments[18],seseSegments[19],seseSegments[20],
                                seseSegments[21], seseSegments[22], seseSegments[23],seseSegments[24],seseSegments[25],
                                seseSegments[26], seseSegments[27], seseSegments[28],seseSegments[29],seseSegments[30],
                                seseSegments[31], seseSegments[32], seseSegments[33],seseSegments[34],seseSegments[35],
                                seseSegments[36], seseSegments[37], seseSegments[38],seseSegments[39],seseSegments[40],
                                seseSegments[41], seseSegments[42], seseSegments[43],seseSegments[44],seseSegments[45],
                                seseSegments[46], seseSegments[47], seseSegments[48],seseSegments[49],seseSegments[50],
                                seseCounts[1],seseCounts[2],seseCounts[3],seseCounts[4],seseCounts[5],seseCounts[6],seseCounts[7],seseCounts[8],
                                seseDurns[1],seseDurns[2],seseDurns[3],seseDurns[4],seseDurns[5],seseDurns[6],seseDurns[7],seseDurns[8],
                                seseInterest[1],seseInterest[2],seseInterest[3],seseInterest[4],seseInterest[5],seseInterest[6],seseInterest[7],seseInterest[8])
  
  
  if (i ==1) {
    seseDF <- seseSession 
  } else {
    seseDF <- rbind(seseDF,seseSession)
  }
}


