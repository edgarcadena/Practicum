#Main Practicum R script
library(ggplot2)
library(scales)

load("~/Personal/UCD/Practicum/R/ETL SeSe  Engagement (seseFinal).RData")
setwd("~/Personal/UCD/Practicum/R")
sese001 <- 0

#Prepare datasets
seseFinal <- seseDF[seseDF$seseSegIndex > 0,]
seseDF <- 0

#========================================
#===      Exploratory analysis       ===
#========================================

###
###  Analysing Interest-based dataset ###
###

str(seseFinal)
summary(seseFinal)

#Basic profiling (durations)
totDurn <- apply(seseFinal[,68:75],1,sum)
seseTest <- cbind(seseFinal,totDurn)
summary(seseTest[seseTest$totDurn > 0,"totDurn"] / 60)

#Basic profiling (sese segments)
summary(seseFinal$seseSegIndex)

#Frequency charts of counts
plot(table(seseFinal$seseCounts.1.))
plot(table(seseFinal$seseCounts.2.))
plot(table(seseFinal$seseCounts.3.))
plot(table(seseFinal$seseCounts.4.))
plot(table(seseFinal$seseCounts.5.))
plot(table(seseFinal$seseCounts.6.))
plot(table(seseFinal$seseCounts.7.))
plot(table(seseFinal$seseCounts.8.))

#Durations density plots
ggplot() + geom_histogram(aes(x=seseFinal[seseFinal$seseDurns.1. > 0,"seseDurns.1."]),binwidth=50, fill="gray")
summary(seseFinal[seseFinal$seseDurns.1. > 0,"seseDurns.1."])
ggplot() + geom_histogram(aes(x=seseFinal[seseFinal$seseDurns.2. > 0,"seseDurns.2."]),binwidth=50, fill="gray")
summary(seseFinal[seseFinal$seseDurns.2. > 0,"seseDurns.2."])
ggplot() + geom_histogram(aes(x=seseFinal[seseFinal$seseDurns.3. > 0,"seseDurns.3."]),binwidth=50, fill="gray")
summary(seseFinal[seseFinal$seseDurns.3. > 0,"seseDurns.3."])
ggplot() + geom_histogram(aes(x=seseFinal[seseFinal$seseDurns.4. > 0,"seseDurns.4."]),binwidth=50, fill="gray")
summary(seseFinal[seseFinal$seseDurns.4. > 0,"seseDurns.4."])
ggplot() + geom_histogram(aes(x=seseFinal[seseFinal$seseDurns.5. > 0,"seseDurns.5."]),binwidth=50, fill="gray")
summary(seseFinal[seseFinal$seseDurns.5. > 0,"seseDurns.5."])
ggplot() + geom_histogram(aes(x=seseFinal[seseFinal$seseDurns.6. > 0,"seseDurns.6."]),binwidth=50, fill="gray")
summary(seseFinal[seseFinal$seseDurns.6. > 0,"seseDurns.6."])
ggplot() + geom_histogram(aes(x=seseFinal[seseFinal$seseDurns.7. > 0,"seseDurns.7."]),binwidth=50, fill="gray")
summary(seseFinal[seseFinal$seseDurns.7. > 0,"seseDurns.7."])
ggplot() + geom_histogram(aes(x=seseFinal[seseFinal$seseDurns.8. > 0,"seseDurns.8."]),binwidth=50, fill="gray")
summary(seseFinal[seseFinal$seseDurns.8. > 0,"seseDurns.8."])

#str(sequenceDF)
ggplot(seseFinal) + geom_density(aes(x=seseInterest.1.)) + scale_x_continuous()
ggplot(seseFinal) + geom_density(aes(x=seseInterest.2.)) + scale_x_continuous()
ggplot(seseFinal) + geom_density(aes(x=seseInterest.3.)) + scale_x_continuous()
ggplot(seseFinal) + geom_density(aes(x=seseInterest.4.)) + scale_x_continuous()
ggplot(seseFinal) + geom_density(aes(x=seseInterest.5.)) + scale_x_continuous()
ggplot(seseFinal) + geom_density(aes(x=seseInterest.6.)) + scale_x_continuous()
ggplot(seseFinal) + geom_density(aes(x=seseInterest.7.)) + scale_x_continuous()
ggplot(seseFinal) + geom_density(aes(x=seseInterest.8.)) + scale_x_continuous()


###
### Analysing Sequence-based dataset
###

hist(seseFinal$seseSegIndex,col = "gray", breaks=100)
plot(table(seseFinal$seseSegments.1.) / sum(table(seseFinal$seseSegments.1.)))
plot(table(seseFinal$seseSegments.2.) / sum(table(seseFinal$seseSegments.2.)))
plot(table(seseFinal$seseSegments.3.) / sum(table(seseFinal$seseSegments.3.)))
plot(table(seseFinal$seseSegments.4.) / sum(table(seseFinal$seseSegments.4.)))


#========================================
#===  Clustering analysis             ===
#========================================

###
###  Analysing Interest-based dataset ###
###


### Pre-analysis using standard parameters and sample data
seseSample <- seseFinal[sample(nrow(seseFinal),20000),]
seseSample <- seseSample[order(seseSample$session_id),]
summary(seseSample)
distSeSe <- dist(seseSample[,c(76:83)],method="euclidean")
hcSeSe <- hclust(distSeSe, method="ward.D")
memberHC <- cutree(hcSeSe, k=k)
png(file="preTestInterestBased.png",width = 8, height = 4, units = 'in', res = 300)
layout(matrix(c(1,1,2,2), 2, 2, byrow = FALSE))
hist(distSeSe,col = "gray", breaks=100, xlab="Distance", main="")
plot(hcSeSe$height[n:(n-50)],type="b", xlab="Number of Clusters", ylab="Clustering height")
rect.hclust(hcSeSe,k=10)
dev.off()


### Main experiment to determine best parameters
hClustMethod <- rep("0",2)
hClustMethod[1] <- "ward.D"      
hClustMethod[2] <- "ward.D2"      
kmeansMethod <- rep("0",3)
kmeansMethod[1] <- "Lloyd"      
kmeansMethod[2] <- "MacQueen"      
kmeansMethod[3] <- "Hartigan-Wong"      

k <- 10      
n <- 20000
iter <- 30
resultsDF <- data.frame()
for (l in 1:length(kmeansMethod)){
#for (l in 1:1){
    for (j in 1:length(hClustMethod)){
    #for (j in 1:1){
     for (i in 1:iter) {
      #Get sample of sessions (R needs more memory to handled all sessions)
      seseSample <- seseFinal[sample(nrow(seseFinal),n),]
      seseSample <- seseSample[order(seseSample$session_id),]
      summary(seseSample)
      
      #Hierarchical clustering
      distSeSe <- dist(seseSample[,c(76:83)],method="euclidean")
      hcSeSe <- hclust(distSeSe, method = hClustMethod[j])
      memberHC <- cutree(hcSeSe, k=k)
      seseSample <- cbind(seseSample,memberHC)
      memberHC <- 0
      filename <- paste("hClust interest test",kmeansMethod[l],hClustMethod[j],i,".png")
      png(file=filename,width=480,height=480)
      layout(matrix(c(1,1,2,3), 2, 2, byrow = FALSE))
      hist(distSeSe,col = "gray", breaks=100)
      plot(hcSeSe$height[n:(n-50)],type="b")
      rect.hclust(hcSeSe,k=k)
      wss <- (nrow(seseSample[,c(76:83)])-1)*sum(apply(seseSample[,c(76:83)],2,var))
      for (t in 2:15) wss[t] <- sum(kmeans(seseSample[,c(76:83)], centers=t)$withinss)
      plot(1:15, wss, type="b", xlab="Number of Clusters",ylab="Within groups sum of squares")
      distSeSe <- 0
      hcSeSe <- 0
      
      #K-means clustering
      kmSeSe <- kmeans(seseSample[,c(76:83)],centers=k,iter.max = 50, nstart=50,algorithm=kmeansMethod[l])
      memberKM <- kmSeSe$cluster
      seseSample <- cbind(seseSample,memberKM)
      memberKM <- 0
      kmSeSe <- 0
      
      #Test clustering solution
      hcTable <- table(seseSample[,84])
      kmTable <- table(seseSample[,85])
      print(hcTable[order(hcTable,decreasing=TRUE)])
      print(kmTable[order(kmTable,decreasing=TRUE)])
      print(sumDiff <- sum(abs((kmTable[order(kmTable,decreasing=TRUE)] / sum(kmTable)) - (hcTable[order(hcTable,decreasing=TRUE)] / sum(hcTable)))))
      print(avgDiff <- mean(abs((kmTable[order(kmTable,decreasing=TRUE)] / sum(kmTable)) - (hcTable[order(hcTable,decreasing=TRUE)] / sum(hcTable)))))
      hcTable <- 0
      kmTable<- 0
      
      resultsIter <- data.frame(kmeansMethod[l],hClustMethod[j],i,sumDiff,avgDiff)
      
      
      if (nrow(resultsDF) == 0) {
        resultsDF <- resultsIter 
      } else {
        resultsDF <- rbind(resultsDF,resultsIter)
      }
      
      #print(resultsDF)
      dev.off()
    }
  }
}
print(tapply(resultsDF$sumDiff,list(resultsDF$hClustMethod.j.,resultsDF$kmeansMethod.l.),FUN=mean))
png(file="interestResults.png",width = 9, height = 6, units = 'in', res = 300)
ggplot(resultsDF, aes(x=hClustMethod.j., y=sumDiff)) + xlab("") + ylab("Cluster Membership error") + geom_boxplot() + facet_grid(.~kmeansMethod.l.)
dev.off()


###
### Analysing Sequence-based dataset ###
###

library(stringdist)
library(cluster)

### Pre-analysis using standard parameters and sample data
n <- 20000
seseSample <- seseFinal[sample(nrow(seseFinal),n),]
seseSample <- seseSample[order(seseSample$session_id),]
summary(seseSample)
distSeq <- stringdistmatrix(seseSample[,9])
hcSeq <- hclust(distSeq, method="ward.D2")
memberHC <- cutree(hcSeq, k=10)
png(file="preSequenceBased.png",width = 8, height = 4, units = 'in', res = 300)
layout(matrix(c(1,1,2,2), 2, 2, byrow = FALSE))
hist(distSeq,col = "gray", breaks=100, xlab="Distance", main="")
plot(hcSeq$height[n:(n-50)],type="b", xlab="Number of Clusters", ylab="Clustering height")
rect.hclust(hcSeq,k=10)
dev.off()

### Main experiment to determine best parameters
hClustMethod <- rep("0",1)
hClustMethod[1] <- "ward.D"      
distMethod <- rep("0",2)
distMethod[1] <- "osa"      
distMethod[2] <- "lv"      

k <- 0      #test variable  
n <- 15000
iter <- 30
nexp <- 3
resultsSeqDF <- data.frame()
for (m in 1:nexp){
  k <- 5*m
  for (l in 1:length(hClustMethod)){
    for (j in 1:length(distMethod)){
      for (i in 1:iter) {
        #Get sample of sessions (R needs more memory to handled all sessions)
        seseSample <- seseFinal[sample(nrow(seseFinal),n),]
        seseSample <- seseSample[order(seseSample$session_id),]
        summary(seseSample)
        
        #Hierarchical clustering
        distSeq <- stringdistmatrix(seseSample[,9],method=distMethod[j])
        hcSeq <- hclust(distSeq, method=hClustMethod[l])
        memberHC <- cutree(hcSeq, k=k)
        filename <- paste("hClust sequence",k,hClustMethod[l],distMethod[j],i,".png")
        png(file=filename,width=480,height=480)
        layout(matrix(c(1,2), 1, 2, byrow = FALSE))
        hist(distSeq,col = "gray", breaks=50)
        plot(hcSeq$height[n:(n-50)],type="b")
        rect.hclust(hcSeq,k=k)
        
        #PAM clustering
        memberPAM <- pam(distSeq,k,TRUE,"euclidean",cluster.only = TRUE)
        
        #Test clustering solution
        hcTable <- table(memberHC)
        pamTable <- table(memberPAM)
        print(hcTable[order(hcTable,decreasing=TRUE)])
        print(pamTable[order(pamTable,decreasing=TRUE)])
        print(sumDiff <- sum(abs((pamTable[order(pamTable,decreasing=TRUE)] / sum(pamTable)) - (hcTable[order(hcTable,decreasing=TRUE)] / sum(hcTable)))))
        print(avgDiff <- mean(abs((pamTable[order(pamTable,decreasing=TRUE)] / sum(pamTable)) - (hcTable[order(hcTable,decreasing=TRUE)] / sum(hcTable)))))
        hcTable <- 0
        pamTable<- 0
        
        resultsSeqIter <- data.frame(k,hClustMethod[l],distMethod[j],i,sumDiff,avgDiff)
        
        
        if (nrow(resultsSeqDF) == 0) {
          resultsSeqDF <- resultsSeqIter 
        } else {
          resultsSeqDF <- rbind(resultsSeqDF,resultsSeqIter)
        }
        
        
        memberHC <- 0
        distSeq <- 0
        hcSeq <- 0
        pamSeq <- 0
        hcTable <- 0
        pamTable <- 0
        dev.off()
        
      }
    }
  }
}
print(tapply(resultsSeqDF$sumDiff,list(as.factor(resultsSeqDF$k),resultsSeqDF$hClustMethod.l.,resultsSeqDF$distMethod.j.),FUN=mean))
png(file="seqResults.png",width = 9, height = 6, units = 'in', res = 300)
ggplot(resultsSeqDF, aes(x=distMethod.j., y=sumDiff)) + xlab("") + ylab("Cluster Membership error") + geom_boxplot() + facet_grid( hClustMethod.l.~k)
dev.off()


#Run kmeans one more time with best parameters 
kmSeSeFinal <- kmeans(seseFinal[,c(76:83)],centers=10,iter.max = 100, nstart=100,algorithm="Hartigan-Wong")
memberKMFinal <- kmSeSeFinal$cluster
seseFinal <- cbind(seseFinal,memberKMFinal)

#Run pam one more time with best parameters 
seseSample <- seseFinal[sample(nrow(seseFinal),20000),]
distSeq <- stringdistmatrix(seseSample[,9],method="osa")
memberPAMFinal <- pam(distSeq,k=15,TRUE,"euclidean",cluster.only = TRUE)
seseSample <- cbind(seseSample,memberPAMFinal)
memberPAM <- rep(0,nrow(seseFinal))
seseFinal <- cbind(seseFinal,memberPAM)
for (i in 1:nrow(seseFinal)){
  if (sum(seseSample$session_id==seseFinal$session_id[i]) > 0){
    print("Found")
    seseFinal[seseFinal$session_id==seseFinal$session_id[i],"memberPAM"] <- seseSample[seseSample$session_id==seseFinal$session_id[i],"memberPAMFinal"]
  }
}

write.table(seseFinal,"SeSeScored-Aug20.csv",quote=TRUE,row.names=FALSE,append=FALSE,sep=",")



